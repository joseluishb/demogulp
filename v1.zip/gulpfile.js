'use strict';
 
var gulp = require('gulp');
var sass = require('gulp-sass');

var sourcemaps = require('gulp-sourcemaps');
var cssnano = require('gulp-cssnano');



gulp.task('sass', function () {
  return gulp.src('./assets/scss/**/*.scss')
    .pipe(sourcemaps.init())
    .pipe(sass().on('error', sass.logError))
    .pipe(cssnano())
    .pipe(sourcemaps.write('maps'))
    .pipe(gulp.dest('./assets/css'));
});


gulp.task('watch:styles', function () {
    gulp.watch('./assets/scss/**/*.scss', gulp.series('sass'));
});
  
gulp.task('watch', gulp.series('sass',
    gulp.parallel('watch:styles')
));



